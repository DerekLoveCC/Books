import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'login-tacocloud',
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
