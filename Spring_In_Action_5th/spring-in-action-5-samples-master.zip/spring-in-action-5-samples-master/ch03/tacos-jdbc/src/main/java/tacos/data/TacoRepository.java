package tacos.data;

import tacos.Taco;

public interface TacoRepository  {

  Taco save(Taco design);
  
}
